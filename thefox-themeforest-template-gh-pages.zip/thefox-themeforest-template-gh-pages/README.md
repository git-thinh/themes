# __THE FOX__
#### Basic html, css, php customizable template

I have bought the original .psd layout from themeforest ([link](https://themeforest.net/item/thefox-multipurpose-psd-template/8894353)) and I worked on it to create a basic html template with css and a simple php file to send email. It's only a demo.

---


## __CONTRIBUTING__

- Fork it!
- Create your feature branch: `git checkout -b my-new-feature`
- Commit your changes: `git commit -am 'Add some feature'`
- Push to the branch: `git push origin my-new-feature`
- Submit a pull request

---
