# themeforest
Download Purchased Theme Forest Items For Free From This Repository. 

<pre>
1- Template: Trend Mag - HTML5 Magazine Template 
   Author URL: http://themeforest.net/user/kopasoft
   Theme Forest Item URL: http://themeforest.net/item/trend-mag-html5-magazine-template/11577441
   GitHub Item URL: http://cannonthemes.github.io/themeforest/trendmag/
</pre>
   
<pre>
2- Template: Peace – Insurance Responsive HTML Template.
   Author URL: http://themeforest.net/user/jitu
   Theme Forest Item URL: http://themeforest.net/item/peace-insurance-responsive-html-template/11509477
   GitHub Item URL: http://cannonthemes.github.io/themeforest/insurance/
</pre>
<pre>
3- Template: Gnoli - Creative Portfolio Template
   Author URL: http://themeforest.net/user/AchtungThemes
   Theme Forest Item URL: http://themeforest.net/item/gnoli-creative-portfolio-template/11547902
   GitHub Item URL: http://cannonthemes.github.io/themeforest/gnoli/
</pre>
