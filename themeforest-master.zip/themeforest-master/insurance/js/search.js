// JavaScript Document
//show and hide search bar
$( document ).ready(function() {
"use strict";
  $(".search").click(function(){
    $(".search-open").slideToggle('1000');
  });
});